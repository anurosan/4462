/*
  ==============================================================================

    This file contains the basic framework code for a JUCE plugin editor.

  ==============================================================================
*/

#include "PluginProcessor.h"
#include "PluginEditor.h"

//==============================================================================
MyArpeggiatorPluginAudioProcessorEditor::MyArpeggiatorPluginAudioProcessorEditor (MyArpeggiatorPluginAudioProcessor& p)
    : AudioProcessorEditor (&p), audioProcessor (p)
{
    // Make sure that before the constructor has finished, you've set the
    // editor's size to whatever you need it to be.
    setSize (200, 600);

    // these define the parameters of our slider object
    arpSlider.setSliderStyle(juce::Slider::LinearBarVertical);
    arpSlider.setRange(0.0, 1.0, 0.05);
    arpSlider.setTextBoxStyle(juce::Slider::NoTextBox, false, 90, 0);
    arpSlider.setPopupDisplayEnabled(true, false, this);
    arpSlider.setTextValueSuffix(" Speed");
    arpSlider.setValue(0.5);

    // this function adds the slider to the editor
    addAndMakeVisible(&arpSlider);
    arpSlider.addListener(this);

    //addAndMakeVisible(textLabel);
    //textLabel.setFont(textFont);
    //textLabel.setColour(1, juce::Colours::red);

    // add items to the combo-box
    addAndMakeVisible(styleMenu);
    styleMenu.addItem("Ascending", 1);
    styleMenu.addItem("Descending", 2);

    styleMenu.onChange = [this] { styleMenuChanged(); };
    styleMenu.setSelectedId(1);

    addAndMakeVisible(octaveMenu);
    octaveMenu.addItem("1", 1);
    octaveMenu.addItem("2", 2);
    octaveMenu.addItem("3", 3);
    octaveMenu.addItem("4", 4);

    octaveMenu.onChange = [this] { octaveMenuChanged(); };
    octaveMenu.setSelectedId(1);
}

MyArpeggiatorPluginAudioProcessorEditor::~MyArpeggiatorPluginAudioProcessorEditor()
{
}

//==============================================================================
void MyArpeggiatorPluginAudioProcessorEditor::paint (juce::Graphics& g)
{
    // (Our component is opaque, so we must completely fill the background with a solid colour)
    g.fillAll (juce::Colours::white);

    g.setColour (juce::Colours::black);
    g.setFont (15.0f);
    g.drawFittedText ("Arpeggiator", 0, 0, getWidth(), 30, juce::Justification::centred, 1);
}

void MyArpeggiatorPluginAudioProcessorEditor::resized()
{
    // This is generally where you'll want to lay out the positions of any
    // subcomponents in your editor..
    
    //textLabel.setBounds(10, 50, getWidth() - 10, 20);
    styleMenu.setBounds(10, 40, getWidth() - 20, 20);
    octaveMenu.setBounds(10, 70, getWidth() - 20, 20);
    arpSlider.setBounds (10, 100, 40, getHeight() - 200);
}

void MyArpeggiatorPluginAudioProcessorEditor::sliderValueChanged(juce::Slider* slider)
{
    audioProcessor.arpSpeed = arpSlider.getValue();
}

void MyArpeggiatorPluginAudioProcessorEditor::styleMenuChanged()
{
    if (styleMenu.getSelectedId() == 2)
    {
        audioProcessor.status = 2;
    }
    else 
    {
        audioProcessor.status = 1;
    }
}

void MyArpeggiatorPluginAudioProcessorEditor::octaveMenuChanged()
{
    if (octaveMenu.getSelectedId() == 4)
    {
        audioProcessor.octave = 4;
    }
    else if (octaveMenu.getSelectedId() == 3)
    {
        audioProcessor.octave = 3;
    }
    if (octaveMenu.getSelectedId() == 2)
    {
        audioProcessor.octave = 2;
    }
    else
    {
        audioProcessor.octave = 1;
    }
}